<?php
/**
 * Unified Authentication and Routing Engine.
 *
 * @package NDS_HR
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class NDS_HR_Auth
 */
class NDS_HR_Auth {

	/**
	 * Meta key linking WP User to Employee ID.
	 */
	const USER_META_EMPLOYEE_ID = '_nds_hr_employee_id';

	/**
	 * Meta key indicating user must change password upon next login.
	 */
	const USER_META_REQUIRE_PASSWORD_CHANGE = '_nds_hr_require_password_change';

	/**
	 * Query variable for the unified login page.
	 */
	const QUERY_VAR_LOGIN = 'nds_hr_login';

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Capability-based login redirection
		add_filter( 'login_redirect', array( $this, 'custom_login_redirect' ), 10, 3 );

		// Restrict /wp-admin/ access based on capability
		add_action( 'admin_init', array( $this, 'restrict_admin_access' ) );

		// Intercept standard wp-login.php and redirect to canonical /login/
		add_action( 'init', array( $this, 'intercept_standard_login' ) );

		// Register /login/ endpoint rewrite rules
		add_action( 'init', array( $this, 'register_login_endpoints' ) );
		add_filter( 'query_vars', array( $this, 'register_login_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'render_login_template' ) );

		// Filter login URL throughout WordPress
		add_filter( 'login_url', array( $this, 'filter_login_url' ), 10, 3 );
	}

	/**
	 * Register frontend rewrite rules for canonical /login/ route.
	 */
	public function register_login_endpoints() {
		add_rewrite_rule( '^login/?$', 'index.php?nds_hr_login=1', 'top' );
	}

	/**
	 * Register login query variable.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function register_login_query_vars( $vars ) {
		$vars[] = self::QUERY_VAR_LOGIN;
		return $vars;
	}

	/**
	 * Filter wp_login_url() to return canonical /login/ URL.
	 *
	 * @param string $login_url
	 * @param string $redirect
	 * @param bool   $force_reauth
	 * @return string
	 */
	public function filter_login_url( $login_url, $redirect = '', $force_reauth = false ) {
		$canonical = home_url( '/login/' );
		if ( ! empty( $redirect ) ) {
			$canonical = add_query_arg( 'redirect_to', urlencode( $redirect ), $canonical );
		}
		if ( $force_reauth ) {
			$canonical = add_query_arg( 'reauth', '1', $canonical );
		}
		return $canonical;
	}

	/**
	 * Intercept standard wp-login.php requests and redirect to canonical /login/.
	 */
	public function intercept_standard_login() {
		global $pagenow;

		// Only intercept on front-facing GET requests for wp-login.php
		if ( 'wp-login.php' === $pagenow && 'GET' === $_SERVER['REQUEST_METHOD'] ) {
			// Do not block logout, lostpassword reset actions if they have specific query parameters
			$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'login';
			if ( 'login' === $action ) {
				$redirect_to = isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : '';
				$login_url   = home_url( '/login/' );
				if ( ! empty( $redirect_to ) ) {
					$login_url = add_query_arg( 'redirect_to', urlencode( $redirect_to ), $login_url );
				}
				wp_safe_redirect( $login_url );
				exit;
			}
		}
	}

	/**
	 * Intercept /login/ template requests and render unified login page.
	 */
	public function render_login_template() {
		if ( 1 !== (int) get_query_var( self::QUERY_VAR_LOGIN ) ) {
			return;
		}

		// Handle change password submission if required
		$this->handle_password_change_submission();

		// If user is already logged in
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$needs_change = get_user_meta( $current_user->ID, self::USER_META_REQUIRE_PASSWORD_CHANGE, true );

			// If user is required to change password on first login, show the change-password modal/view
			if ( '1' === (string) $needs_change ) {
				$this->render_login_view();
				exit;
			}

			$destination = $this->determine_post_login_url( $current_user );
			wp_safe_redirect( $destination );
			exit;
		}

		$this->handle_login_submission();
		$this->render_login_view();
		exit;
	}

	/**
	 * Process login form submissions from the unified login screen.
	 */
	protected function handle_login_submission() {
		if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || ! isset( $_POST['nds_hr_login_action'] ) || 'submit_login' !== $_POST['nds_hr_login_action'] ) {
			return;
		}

		// Verify security nonce
		if ( ! NDS_HR_Security::verify_nonce( 'nds_hr_unified_login', 'nds_hr_login_nonce' ) ) {
			wp_safe_redirect( add_query_arg( 'login_error', 'nonce_failed', home_url( '/login/' ) ) );
			exit;
		}

		$credentials = array(
			'user_login'    => isset( $_POST['log'] ) ? sanitize_user( wp_unslash( $_POST['log'] ) ) : '',
			'user_password' => isset( $_POST['pwd'] ) ? $_POST['pwd'] : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			'remember'      => ! empty( $_POST['rememberme'] ),
		);

		// Execute standard secure WordPress authentication
		$user = wp_signon( $credentials, is_ssl() );

		if ( is_wp_error( $user ) ) {
			$error_code = $user->get_error_code();
			$redirect_url = add_query_arg(
				array(
					'login_error' => $error_code,
					'log'         => urlencode( $credentials['user_login'] ),
				),
				home_url( '/login/' )
			);
			wp_safe_redirect( $redirect_url );
			exit;
		}

		// Check if password change is required on first login
		$require_change = get_user_meta( $user->ID, self::USER_META_REQUIRE_PASSWORD_CHANGE, true );
		if ( '1' === (string) $require_change ) {
			wp_safe_redirect( home_url( '/login/?require_pw_change=1' ) );
			exit;
		}

		// Check explicit redirect_to parameter if provided and safe
		$redirect_param = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
		if ( ! empty( $redirect_param ) && false === strpos( $redirect_param, 'wp-login.php' ) && false === strpos( $redirect_param, '/login' ) ) {
			$safe_destination = wp_validate_redirect( $redirect_param, '' );
			if ( ! empty( $safe_destination ) ) {
				// If user does not have admin capability, do not let them redirect to wp-admin
				if ( strpos( $safe_destination, 'wp-admin' ) !== false && ! user_can( $user, 'nds_hr_access_admin' ) && ! user_can( $user, 'manage_options' ) ) {
					$safe_destination = home_url( '/employee/' );
				}
				wp_safe_redirect( $safe_destination );
				exit;
			}
		}

		// Route based on user capabilities
		$destination = $this->determine_post_login_url( $user );
		wp_safe_redirect( $destination );
		exit;
	}

	/**
	 * Process first-login password change submission.
	 */
	protected function handle_password_change_submission() {
		if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || ! isset( $_POST['nds_hr_login_action'] ) || 'change_required_password' !== $_POST['nds_hr_login_action'] ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/login/' ) );
			exit;
		}

		// Verify nonce
		if ( ! NDS_HR_Security::verify_nonce( 'nds_hr_password_change', 'nds_hr_pw_change_nonce' ) ) {
			wp_safe_redirect( add_query_arg( array( 'require_pw_change' => 1, 'pw_error' => 'nonce_failed' ), home_url( '/login/' ) ) );
			exit;
		}

		$current_user = wp_get_current_user();
		$new_password = isset( $_POST['new_password'] ) ? $_POST['new_password'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$confirm_password = isset( $_POST['confirm_password'] ) ? $_POST['confirm_password'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( empty( $new_password ) || empty( $confirm_password ) ) {
			wp_safe_redirect( add_query_arg( array( 'require_pw_change' => 1, 'pw_error' => 'empty_fields' ), home_url( '/login/' ) ) );
			exit;
		}

		if ( $new_password !== $confirm_password ) {
			wp_safe_redirect( add_query_arg( array( 'require_pw_change' => 1, 'pw_error' => 'password_mismatch' ), home_url( '/login/' ) ) );
			exit;
		}

		if ( strlen( $new_password ) < 8 ) {
			wp_safe_redirect( add_query_arg( array( 'require_pw_change' => 1, 'pw_error' => 'password_too_short' ), home_url( '/login/' ) ) );
			exit;
		}

		// Native WordPress secure password reset
		wp_set_password( $new_password, $current_user->ID );

		// Remove the required change flag (store only flag, never the password)
		delete_user_meta( $current_user->ID, self::USER_META_REQUIRE_PASSWORD_CHANGE );

		// Re-authenticate user session after password reset
		wp_set_current_user( $current_user->ID );
		wp_set_auth_cookie( $current_user->ID );

		// Audit the password update
		NDS_HR_Audit_Logger::log(
			'first_login_password_changed',
			'user',
			$current_user->ID,
			array( 'status' => 'password_change_required' ),
			array( 'status' => 'password_updated_successfully' )
		);

		// Route based on user capabilities
		$destination = $this->determine_post_login_url( $current_user );
		wp_safe_redirect( $destination );
		exit;
	}

	/**
	 * Route user after login based on capability evaluation.
	 *
	 * @param WP_User $user
	 * @return string Target destination URL.
	 */
	public function determine_post_login_url( WP_User $user ) {
		// 1. Check if user has administrative capability (HR Admin, HR Manager, Officer, WP Admin)
		if ( user_can( $user, 'nds_hr_access_admin' ) || user_can( $user, 'manage_options' ) ) {
			return admin_url( 'admin.php?page=nds-hr' );
		}

		// 2. Check if user has employee portal access capability
		if ( user_can( $user, 'nds_hr_access_employee' ) || user_can( $user, 'nds_hr_view_own_profile' ) ) {
			return home_url( '/employee/' );
		}

		// 3. Fallback for any other user role
		return home_url( '/' );
	}

	/**
	 * Filter for standard wp_login_redirect hook.
	 *
	 * @param string           $redirect_to
	 * @param string           $request
	 * @param WP_User|WP_Error $user
	 * @return string
	 */
	public function custom_login_redirect( $redirect_to, $request, $user ) {
		if ( ! is_wp_error( $user ) && is_a( $user, 'WP_User' ) ) {
			// If password change is required
			$require_change = get_user_meta( $user->ID, self::USER_META_REQUIRE_PASSWORD_CHANGE, true );
			if ( '1' === (string) $require_change ) {
				return home_url( '/login/?require_pw_change=1' );
			}

			// If a specific, safe custom redirect was requested (e.g. deep link)
			if ( ! empty( $request ) && false === strpos( $request, 'wp-login.php' ) && false === strpos( $request, '/login' ) ) {
				if ( strpos( $request, 'wp-admin' ) !== false && ! user_can( $user, 'nds_hr_access_admin' ) && ! user_can( $user, 'manage_options' ) ) {
					return home_url( '/employee/' );
				}
				return $request;
			}

			return $this->determine_post_login_url( $user );
		}

		return $redirect_to;
	}

	/**
	 * Restrict access to /wp-admin/ for users without nds_hr_access_admin capability.
	 * Redirects them smoothly to the frontend Employee Portal.
	 */
	public function restrict_admin_access() {
		// Do not block admin-ajax.php or admin-post.php requests
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();

			// If user must change password
			$require_change = get_user_meta( $user->ID, self::USER_META_REQUIRE_PASSWORD_CHANGE, true );
			if ( '1' === (string) $require_change ) {
				wp_safe_redirect( home_url( '/login/?require_pw_change=1' ) );
				exit;
			}

			// If user lacks admin capability and cannot manage options
			if ( ! user_can( $user, 'nds_hr_access_admin' ) && ! user_can( $user, 'manage_options' ) ) {
				// Prevent loop if already on frontend
				wp_safe_redirect( home_url( '/employee/' ) );
				exit;
			}
		}
	}

	/**
	 * Render the unified branded login view template.
	 */
	protected function render_login_view() {
		include NDS_HR_PATH . 'templates/login/login.php';
	}

	/**
	 * Create a real WordPress user account for an employee.
	 *
	 * @param array $account_data Username, email, password, etc.
	 * @return array|WP_Error Array with user_id and plain password (for session display only), or WP_Error.
	 */
	public static function create_employee_user_account( array $account_data ) {
		$username = sanitize_user( $account_data['username'] ?? '' );
		$email    = sanitize_email( $account_data['email'] ?? '' );

		// Auto-generate strong secure password if blank
		$provided_password = ! empty( $account_data['password'] ) ? $account_data['password'] : '';
		$password          = ! empty( $provided_password ) ? $provided_password : wp_generate_password( 14, true, true );

		if ( empty( $username ) ) {
			return new WP_Error( 'empty_username', __( 'Username is required to create a user account.', 'nds-hr' ) );
		}

		if ( username_exists( $username ) ) {
			return new WP_Error( 'username_exists', __( 'This username is already registered in WordPress.', 'nds-hr' ) );
		}

		if ( empty( $email ) || ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', __( 'A valid email address is required.', 'nds-hr' ) );
		}

		if ( email_exists( $email ) ) {
			return new WP_Error( 'email_exists', __( 'This email address is already in use.', 'nds-hr' ) );
		}

		$user_id = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_email'   => $email,
				'user_pass'    => $password,
				'first_name'   => sanitize_text_field( $account_data['first_name'] ?? '' ),
				'last_name'    => sanitize_text_field( $account_data['last_name'] ?? '' ),
				'display_name' => sanitize_text_field( $account_data['full_name'] ?? $username ),
				'role'         => NDS_HR_Roles::ROLE_EMPLOYEE,
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		// Optional: Require password change on first login
		if ( ! empty( $account_data['require_password_change'] ) ) {
			update_user_meta( $user_id, self::USER_META_REQUIRE_PASSWORD_CHANGE, '1' );
		}

		// Send notification if requested
		if ( ! empty( $account_data['send_notification'] ) ) {
			wp_new_user_notification( $user_id, null, 'user' );
		}

		return array(
			'user_id'                 => $user_id,
			'username'                => $username,
			'email'                   => $email,
			'temporary_password'      => $password,
			'require_password_change' => ! empty( $account_data['require_password_change'] ),
		);
	}

	/**
	 * Bidirectionally link a WordPress User to an Employee record.
	 *
	 * @param int $user_id
	 * @param int $employee_db_id
	 */
	public static function link_user_to_employee( $user_id, $employee_db_id ) {
		update_user_meta( $user_id, self::USER_META_EMPLOYEE_ID, absint( $employee_db_id ) );
	}

	/**
	 * Get Employee DB record ID linked to a WordPress User ID.
	 *
	 * @param int $user_id
	 * @return int|false
	 */
	public static function get_employee_id_by_user( $user_id ) {
		$emp_id = get_user_meta( $user_id, self::USER_META_EMPLOYEE_ID, true );
		if ( ! empty( $emp_id ) ) {
			return absint( $emp_id );
		}

		// Fallback query to employee table if user meta is not yet set
		global $wpdb;
		$table     = NDS_HR_Database::employees_table();
		$emp_db_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE user_id = %d LIMIT 1", $user_id ) );

		if ( $emp_db_id ) {
			self::link_user_to_employee( $user_id, $emp_db_id );
			return absint( $emp_db_id );
		}

		return false;
	}
}
