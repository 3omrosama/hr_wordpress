<?php
/**
 * Permissions and Centralized Authorization Engine.
 *
 * @package NDS_HR
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class NDS_HR_Permissions
 */
class NDS_HR_Permissions {

	/**
	 * Generic capability check on a given user or current user.
	 *
	 * @param string   $capability Capability name.
	 * @param int|null $user_id    User ID or null for current user.
	 * @return bool
	 */
	public static function can( $capability, $user_id = null ) {
		if ( null === $user_id ) {
			if ( ! is_user_logged_in() ) {
				return false;
			}
			return current_user_can( $capability ) || current_user_can( 'manage_options' );
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		return user_can( $user, $capability ) || user_can( $user, 'manage_options' );
	}

	/**
	 * Check if user can access the HR wp-admin administration area.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_access_admin( $user_id = null ) {
		return self::can( 'nds_hr_access_admin', $user_id );
	}

	/**
	 * Check if user can access the frontend Employee Self-Service Portal (/employee/).
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_access_portal( $user_id = null ) {
		return self::can( 'nds_hr_access_employee', $user_id ) || self::can( 'nds_hr_view_own_profile', $user_id );
	}

	/**
	 * Check if user can manage roles and capability assignments.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_manage_roles( $user_id = null ) {
		return self::can( 'nds_hr_manage_roles', $user_id );
	}

	/**
	 * Check if user can view the employee directory.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_view_employees( $user_id = null ) {
		return self::can( 'nds_hr_view_employees', $user_id ) || self::can( 'nds_hr_manage_employees', $user_id );
	}

	/**
	 * Check if user can create or manage employees.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_manage_employees( $user_id = null ) {
		return self::can( 'nds_hr_manage_employees', $user_id );
	}

	/**
	 * Check if user can edit an employee record.
	 *
	 * @param int      $employee_db_id Employee internal database ID.
	 * @param int|null $user_id        WP User checking or null for current.
	 * @return bool
	 */
	public static function can_edit_employee( $employee_db_id = 0, $user_id = null ) {
		return self::can( 'nds_hr_edit_employees', $user_id ) || self::can( 'nds_hr_manage_employees', $user_id );
	}

	/**
	 * Check if user can delete an employee record.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_delete_employees( $user_id = null ) {
		return self::can( 'nds_hr_delete_employees', $user_id );
	}

	/**
	 * Check if user can view a given employee record.
	 * HR Managers can view all; employees can ONLY view their own record.
	 *
	 * @param int      $employee_db_id Employee internal database ID.
	 * @param int|null $user_id        Optional WP User ID.
	 * @return bool
	 */
	public static function can_view_employee( $employee_db_id, $user_id = null ) {
		if ( self::can_view_employees( $user_id ) ) {
			return true;
		}

		$wp_user_id = $user_id ? absint( $user_id ) : get_current_user_id();
		if ( ! $wp_user_id ) {
			return false;
		}

		return self::is_employee_owner( $employee_db_id, $wp_user_id );
	}

	/**
	 * Ownership check: verify if an employee record belongs to the given WP user.
	 *
	 * @param int $employee_db_id
	 * @param int $wp_user_id
	 * @return bool
	 */
	public static function is_employee_owner( $employee_db_id, $wp_user_id ) {
		global $wpdb;

		if ( empty( $employee_db_id ) || empty( $wp_user_id ) ) {
			return false;
		}

		$table = NDS_HR_Database::employees_table();
		$owner = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE id = %d AND user_id = %d LIMIT 1",
				$employee_db_id,
				$wp_user_id
			)
		);

		return ! empty( $owner );
	}

	/**
	 * Check if user can view audit and compliance logs.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_view_audit_logs( $user_id = null ) {
		return self::can( 'nds_hr_view_audit_logs', $user_id );
	}

	/**
	 * Check if user can manage departments and positions.
	 *
	 * @param int|null $user_id
	 * @return bool
	 */
	public static function can_manage_departments( $user_id = null ) {
		return self::can( 'nds_hr_manage_departments', $user_id );
	}
}
