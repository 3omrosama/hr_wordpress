<?php
/**
 * Database Management and Schema Migration Class.
 *
 * @package NDS_HR
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class NDS_HR_Database
 */
class NDS_HR_Database {

	/**
	 * Database version option key.
	 */
	const DB_VERSION_KEY = 'nds_hr_db_version';

	/**
	 * Table name accessors.
	 *
	 * @param string $name Short table identifier.
	 * @return string Full prefixed table name.
	 */
	public static function get_table_name( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'nds_hr_' . $name;
	}

	/**
	 * Shortcut table name helpers.
	 */
	public static function employees_table() {
		return self::get_table_name( 'employees' );
	}

	public static function departments_table() {
		return self::get_table_name( 'departments' );
	}

	public static function positions_table() {
		return self::get_table_name( 'positions' );
	}

	public static function audit_logs_table() {
		return self::get_table_name( 'audit_logs' );
	}

	/**
	 * Run on plugin activation or manual update.
	 */
	public static function install() {
		$current_db_version = get_option( self::DB_VERSION_KEY, '0.0.0' );

		if ( version_compare( $current_db_version, NDS_HR_DB_VERSION, '<' ) ) {
			self::run_migrations( $current_db_version );
			update_option( self::DB_VERSION_KEY, NDS_HR_DB_VERSION );
		}
	}

	/**
	 * Check for database updates during runtime.
	 */
	public function check_updates() {
		$installed_version = get_option( self::DB_VERSION_KEY, '0.0.0' );
		if ( version_compare( $installed_version, NDS_HR_DB_VERSION, '<' ) ) {
			self::install();
		}
	}

	/**
	 * Execute migrations based on version.
	 *
	 * @param string $from_version Currently installed version.
	 */
	protected static function run_migrations( $from_version ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Phase 1 Initial Schema
		if ( version_compare( $from_version, '1.0.0', '<' ) ) {
			self::create_phase_1_tables();
			self::seed_initial_defaults();
		}
	}

	/**
	 * Create all custom tables required for Phase 1.
	 */
	protected static function create_phase_1_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$departments_table = self::departments_table();
		$positions_table   = self::positions_table();
		$employees_table   = self::employees_table();
		$audit_logs_table  = self::audit_logs_table();

		// 1. Departments table
		$sql_departments = "CREATE TABLE {$departments_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(150) NOT NULL,
			code varchar(50) NOT NULL,
			description text DEFAULT NULL,
			manager_id bigint(20) unsigned DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			KEY manager_id (manager_id)
		) {$charset_collate};";

		// 2. Positions table
		$sql_positions = "CREATE TABLE {$positions_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			department_id bigint(20) unsigned DEFAULT NULL,
			title varchar(150) NOT NULL,
			code varchar(50) NOT NULL,
			description text DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			KEY department_id (department_id)
		) {$charset_collate};";

		// 3. Employees table
		$sql_employees = "CREATE TABLE {$employees_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			employee_id varchar(50) NOT NULL,
			user_id bigint(20) unsigned DEFAULT NULL,
			first_name varchar(100) NOT NULL,
			last_name varchar(100) NOT NULL,
			full_name varchar(200) NOT NULL,
			email varchar(100) NOT NULL,
			phone varchar(50) DEFAULT '',
			mobile varchar(50) DEFAULT '',
			national_id varchar(50) DEFAULT '',
			date_of_birth date DEFAULT NULL,
			gender varchar(20) DEFAULT 'male',
			hire_date date NOT NULL,
			department_id bigint(20) unsigned DEFAULT NULL,
			position_id bigint(20) unsigned DEFAULT NULL,
			employment_status varchar(30) NOT NULL DEFAULT 'active',
			manager_id bigint(20) unsigned DEFAULT NULL,
			basic_salary decimal(12,2) NOT NULL DEFAULT 0.00,
			profile_photo_url text DEFAULT NULL,
			address text DEFAULT NULL,
			emergency_contact_name varchar(100) DEFAULT '',
			emergency_contact_phone varchar(50) DEFAULT '',
			emergency_contact_relationship varchar(50) DEFAULT '',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY employee_id (employee_id),
			KEY user_id (user_id),
			KEY department_id (department_id),
			KEY position_id (position_id),
			KEY status (employment_status),
			KEY hire_date (hire_date),
			KEY email (email)
		) {$charset_collate};";

		// 4. Audit Logs table
		$sql_audit_logs = "CREATE TABLE {$audit_logs_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(100) NOT NULL,
			entity_type varchar(50) NOT NULL,
			entity_id bigint(20) unsigned NOT NULL DEFAULT 0,
			old_values longtext DEFAULT NULL,
			new_values longtext DEFAULT NULL,
			ip_address varchar(100) DEFAULT '',
			user_agent text DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY action (action),
			KEY entity_lookup (entity_type, entity_id),
			KEY user_id (user_id),
			KEY created_at (created_at)
		) {$charset_collate};";

		// Execute with dbDelta
		dbDelta( $sql_departments );
		dbDelta( $sql_positions );
		dbDelta( $sql_employees );
		dbDelta( $sql_audit_logs );
	}

	/**
	 * Seed initial demo departments and positions if table is empty.
	 */
	protected static function seed_initial_defaults() {
		global $wpdb;

		$departments_table = self::departments_table();
		$count = $wpdb->get_var( "SELECT COUNT(*) FROM {$departments_table}" );

		if ( 0 === (int) $count ) {
			// Seed Core Departments
			$wpdb->insert(
				$departments_table,
				array(
					'name'        => 'Human Resources',
					'code'        => 'HR',
					'description' => 'Human resources and people management department.',
				),
				array( '%s', '%s', '%s' )
			);
			$hr_id = $wpdb->insert_id;

			$wpdb->insert(
				$departments_table,
				array(
					'name'        => 'Information Technology',
					'code'        => 'IT',
					'description' => 'Software engineering, systems and technical infrastructure.',
				),
				array( '%s', '%s', '%s' )
			);
			$it_id = $wpdb->insert_id;

			$wpdb->insert(
				$departments_table,
				array(
					'name'        => 'Finance & Accounting',
					'code'        => 'FIN',
					'description' => 'Financial planning, accounting and payroll administration.',
				),
				array( '%s', '%s', '%s' )
			);
			$fin_id = $wpdb->insert_id;

			$wpdb->insert(
				$departments_table,
				array(
					'name'        => 'Sales & Marketing',
					'code'        => 'SALES',
					'description' => 'Business development, client relations and marketing.',
				),
				array( '%s', '%s', '%s' )
			);
			$sales_id = $wpdb->insert_id;

			// Seed Core Positions
			$positions_table = self::positions_table();

			$default_positions = array(
				array( 'department_id' => $hr_id, 'title' => 'HR Director', 'code' => 'HR-DIR' ),
				array( 'department_id' => $hr_id, 'title' => 'HR Specialist', 'code' => 'HR-SPEC' ),
				array( 'department_id' => $it_id, 'title' => 'Senior Software Engineer', 'code' => 'IT-SWE' ),
				array( 'department_id' => $it_id, 'title' => 'DevOps Specialist', 'code' => 'IT-DEVOPS' ),
				array( 'department_id' => $fin_id, 'title' => 'Financial Analyst', 'code' => 'FIN-ANALYST' ),
				array( 'department_id' => $fin_id, 'title' => 'Accountant', 'code' => 'FIN-ACC' ),
				array( 'department_id' => $sales_id, 'title' => 'Sales Executive', 'code' => 'SALES-EXEC' ),
			);

			foreach ( $default_positions as $pos ) {
				$wpdb->insert(
					$positions_table,
					array(
						'department_id' => $pos['department_id'],
						'title'         => $pos['title'],
						'code'          => $pos['code'],
						'description'   => $pos['title'] . ' role in company.',
					),
					array( '%d', '%s', '%s', '%s' )
				);
			}
		}
	}

	/**
	 * Architectural Schema Registry for Future Modules.
	 * Returns blueprint schema metadata for Phase 2-6 tables.
	 *
	 * @return array
	 */
	public static function get_future_modules_schema_registry() {
		return array(
			'attendance' => array(
				'table'       => 'nds_hr_attendance',
				'phase'       => 2,
				'description' => 'Daily check-in / check-out records, status (present, late, absent), duration, geolocation.',
			),
			'leave_types' => array(
				'table'       => 'nds_hr_leave_types',
				'phase'       => 3,
				'description' => 'Annual, Sick, Maternity, Emergency leaves configuration, carry-over rules, allowances.',
			),
			'leave_balances' => array(
				'table'       => 'nds_hr_leave_balances',
				'phase'       => 3,
				'description' => 'Yearly allocated, taken, pending, and remaining balances per employee.',
			),
			'leave_requests' => array(
				'table'       => 'nds_hr_leave_requests',
				'phase'       => 3,
				'description' => 'Employee leave requests, date ranges, reasons, approval workflow status, approver ID.',
			),
			'payroll' => array(
				'table'       => 'nds_hr_payroll',
				'phase'       => 4,
				'description' => 'Monthly payroll runs, cycle period, payment date, totals, status (draft, processed, paid).',
			),
			'payroll_items' => array(
				'table'       => 'nds_hr_payroll_items',
				'phase'       => 4,
				'description' => 'Individual line items per employee: allowances, deductions, overtime, bonuses, tax.',
			),
			'payslips' => array(
				'table'       => 'nds_hr_payslips',
				'phase'       => 5,
				'description' => 'Generated payslip documents, unique reference number, net pay summary, distribution status.',
			),
			'notifications' => array(
				'table'       => 'nds_hr_notifications',
				'phase'       => 6,
				'description' => 'In-app and email alert queue for leaves, onboarding, approvals, and payroll.',
			),
		);
	}
}
